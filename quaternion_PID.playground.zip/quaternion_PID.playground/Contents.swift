import Foundation
import simd

extension Comparable {
    func clamped(to limits: ClosedRange<Self>) -> Self {
        return min(max(self, limits.lowerBound), limits.upperBound)
    }
}

#if swift(<5.1)
extension Strideable where Stride: SignedInteger {
    func clamped(to limits: CountableClosedRange<Self>) -> Self {
        return min(max(self, limits.lowerBound), limits.upperBound)
    }
}
#endif

func quaternionToEuler(_ q: simd_quatd) -> simd_double3 {
    
    var e = simd_double3()
    
    e.x = atan2(2 * (q.real * q.imag.x + q.imag.y * q.imag.z), pow(q.real, 2) - pow(q.imag.x, 2) - pow(q.imag.y, 2) + pow(q.imag.z, 2))
    
    e.y = asin(2 * (q.real * q.imag.y - q.imag.x * q.imag.z))
    
    e.z = atan2(2 * (q.real * q.imag.z + q.imag.x * q.imag.y), pow(q.real, 2) + pow(q.imag.x, 2) - pow(q.imag.y, 2) - pow(q.imag.z, 2))
    
    if abs(e.x) == .pi {
        e.x = 0
        e.y = .pi - e.y
        e.z = -1 * (.pi - e.z)
    }
    
    return e
}

func eulerToQuaternion(_ e: simd_double3) -> simd_quatd {
    
    var q = simd_quatd()
    
    q.real = cos(e.x / 2) * cos(e.y / 2) * cos(e.z / 2) + sin(e.x / 2) * sin(e.y / 2) * sin(e.z / 2)
    
    q.imag.x = sin(e.x / 2) * cos(e.y / 2) * cos(e.z / 2) - cos(e.x / 2) * sin(e.y / 2) * sin(e.z / 2)
    
    q.imag.y = cos(e.x / 2) * sin(e.y / 2) * cos(e.z / 2) + sin(e.x / 2) * cos(e.y / 2) * sin(e.z / 2)
    
    q.imag.z = cos(e.x / 2) * cos(e.y / 2) * sin(e.z / 2) - sin(e.x / 2) * sin(e.y / 2) * cos(e.z / 2)
    
    return q
}

func error(a: simd_quatd, d: simd_quatd) -> simd_quatd {
    return d * simd_conjugate(a)
}

func errorToAxis(e: simd_quatd) -> simd_double3 {
    return simd_double3(x: e.imag.x, y: e.imag.y, z: e.imag.z)
}

let timeInterval = 0.1
var previousError = simd_double3()
var accumulatedError = simd_double3()

func PID(e: simd_double3, kp: Double, ki: Double, kd: Double) -> simd_double3 {
    
    let p = kp * e
    
    accumulatedError += (e * timeInterval)
    let i = ki * accumulatedError
    
    let d = kd * (e - previousError)
    previousError = e
    
    //print("pid = [x: [p: \(p.x), i: \(i.x), d: \(d.x)], y: [p: \(p.y), i: \(i.y), d: \(d.y)], z: [p: \(p.z), i: \(i.z), d: \(d.z)]]")
    
    return p + i + d
}

func rotate(a: simd_quatd, w: simd_double3) -> simd_quatd {
    let rotation = simd_quatd(real: cos((length(w) * timeInterval) / 2), imag: sin((length(w) * timeInterval) / 2) * (w / length(w)))
    return rotation * a
}

var actualAttitude = [eulerToQuaternion(simd_double3(x: 0.0, y: 0.0, z: 0))]
var desiredAttitude = [eulerToQuaternion(simd_double3(x: 0, y: 0, z: 0)),
                       eulerToQuaternion(simd_double3(x: 0.1, y: 0, z: 0)),
                       eulerToQuaternion(simd_double3(x: 0, y: -0.1, z: 0)),
                       eulerToQuaternion(simd_double3(x: 0, y: 0, z: 0.05))]
var disturbance = simd_double3(x: 0.05, y: 0.1, z: 0)
var actualError = [simd_quatd]()
var time = [Double]()

let kp = 9.0
let ki = 3.0
let kd = 1.0

func vectorToQuaternion(_ v: simd_double3) -> simd_quatd {
    
    let a = simd_cross(simd_double3(x: 0, y: 0, z: 1), v)
    return simd_quatd(real: sqrt(pow(simd_length(simd_double3(x: 0, y: 0, z: 1)), 2) * pow(simd_length(v), 2)) + simd_dot(simd_double3(x: 0, y: 0, z: 1), v), imag: a)
}

func rotate(v: simd_double3, q: simd_quatd) -> simd_double3 {
    let qn = q * simd_quatd(real: 0, imag: v) * simd_conjugate(q)
    return qn.imag
}

func perpendicular(v0: simd_double3, v1: simd_double3) -> simd_double3 {
    return -simd_cross(simd_cross( v0, v1), v1)
}

func torque(p: simd_double3, v: simd_double3) -> simd_double3 {
    return simd_cross(p, v)
}

func torque2D(r: simd_double2, f: simd_double2) -> simd_double3 {
    return simd_cross(r, f)
}

let r = 0.25 * simd_normalize(simd_double2(x: -1, y: 1))
let f = 1 * simd_normalize(simd_double2(x: 20, y: -34))
let t = torque2D(r: r, f: f)

print(t)

/*for i in 0...100 {
    time.append(timeInterval * Double(i))
    //print("T+\(time[i]):")
    
    switch time[i] {
    case 0..<2:
        actualError.append(error(a: actualAttitude[i], d: desiredAttitude[0]))
        print(quaternionToEuler(desiredAttitude[0]).z)
    case 2..<4:
        actualError.append(error(a: actualAttitude[i], d: desiredAttitude[1]))
        print(quaternionToEuler(desiredAttitude[1]).z)
    case 5..<7:
        actualError.append(error(a: actualAttitude[i], d: desiredAttitude[2]))
        print(quaternionToEuler(desiredAttitude[2]).z)
    case 8..<10:
        actualError.append(error(a: actualAttitude[i], d: desiredAttitude[3]))
        print(quaternionToEuler(desiredAttitude[3]).z)
    default:
        actualError.append(error(a: actualAttitude[i], d: desiredAttitude[0]))
        print(quaternionToEuler(desiredAttitude[0]).z)
    }
    let axisError = errorToAxis(e: actualError[i])
    
    var w = PID(e: axisError, kp: kp, ki: ki, kd: kd)
    w = simd_double3(x: w.x.clamped(to: -1...1),
                     y: w.y.clamped(to: -1...1),
                     z: w.z.clamped(to: -0.5...0.5))
    actualAttitude.append(rotate(a: actualAttitude[i], w: (w + disturbance)))
    
    let actualAngles = quaternionToEuler(actualAttitude[i])
    
    //print(time[i])
    //print(actualAngles.z)
    
    //print("error = [x: \(actualAngles.x), y: \(actualAngles.y), z: \(actualAngles.z)]")
}
*/
